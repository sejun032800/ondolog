# Nocturne v5 — 변경 기록

## patch1 (2026-10-22) — 디자인 R20 요청 반영

캔버스 HTML만 바뀌었다. **화면 그림(`screens/`)은 아직 이전 판이다** — patch2에서 바뀐다(ROADMAP R22-7).
그림과 HTML이 다르면 **HTML을 따른다.**

| 파일 | 바뀐 것 |
|---|---|
| `canvas/P1-Cover-Note.dc.html` | **신규.** 표지(사진·활자) · 발행 노트 템플릿. 호 번호·발행일 없음. `55-` 조판의 표지·발행 노트 원본 |
| `canvas/Tokens.dc.html` | `lilacText #D7C9FA` 추가, 장막 값 |
| `canvas/Objects-1.dc.html` | 하늘 장막 값(main .42 / pullStart .30 / pullRelease .14 / sky 0) + 메인 하단 장막 |
| `canvas/Objects-3.dc.html` | 속표지 오브젝트에서 호 번호 제거 |
| `canvas/N-D10-Front-Matter.dc.html` | 속표지 — 호 번호 제거 |
| `canvas/N-S-D2-Magazine.dc.html` | D09 발행 완료·D13 서재 — 표지 안 호 번호 제거(표지 밖 라벨은 유지) |
| `canvas/N-S-D3-Magazine.dc.html` | D15 공유 카드 — 호 번호 제거 |
| `canvas/N-T-Tabs.dc.html` | D01 서재 표지 — 호 번호 제거 |
| `canvas/M1-Editorial-Mix.dc.html` · `canvas/canvas.json` | 위에 맞춘 갱신 |

**PM 결정과 다른 곳(디자인 세션에 요청함, R22)** — 두 표지 모두 "N월호" 필수(R22-3), 활자 표지 네온 테마 추가(R22-6),
D15 공유 카드는 본인 원문만(R22-5). 이 셋은 patch2에서 그림과 함께 바뀐다. 그 전에는 MASTER 9-5 r64를 따른다.
